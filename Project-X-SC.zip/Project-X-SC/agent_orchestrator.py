import logging
import uuid
import time
import threading

logger = logging.getLogger(__name__)

class AgentOrchestrator:
    def __init__(self, docker_image_prefix: str = "ai_agent_", container_network: str = "bridge"):
        logger.info(f"AgentOrchestrator initialized with image prefix '{docker_image_prefix}' and network '{container_network}'.")
        self.docker_image_prefix = docker_image_prefix
        self.container_network = container_network
        self.active_containers = {} # Stores {agent_id: {"type": agent_type, "task": task, "start_time": time, "thread": thread_obj}}
        self.max_agents = 5 # Example limit

    def spawn_agent(self, agent_type: str, task_description: str, runtime_limit_seconds: int = 300) -> str | None:
        """
        Simulates spawning a new agent (e.g., a Docker container or a separate process).
        In a real scenario, this would use Docker SDK or subprocess.
        """
        if len(self.active_containers) >= self.max_agents:
            logger.warning("Max agents reached. Cannot spawn new agent.")
            return None

        # Basic policy check using policy_engine (re-import if not globally accessible)
        from policy_engine import can_spawn_agent
        try:
            can_spawn_agent(agent_type, task_description)
        except Exception as e: # Catch PolicyViolationError
            logger.error(f"Policy violation prevented agent spawn: {e}")
            return None

        agent_id = str(uuid.uuid4())
        logger.info(f"AgentOrchestrator: Simulating spawn of agent '{agent_type}' (ID: {agent_id[:8]}) for task: '{task_description[:50]}'...")

        # Simulate agent execution in a separate thread
        agent_thread = threading.Thread(
            target=self._simulate_agent_work,
            args=(agent_id, agent_type, task_description, runtime_limit_seconds)
        )
        agent_thread.daemon = True # Allow main program to exit even if agents are running

        self.active_containers[agent_id] = {
            "type": agent_type,
            "task": task_description,
            "runtime_limit": runtime_limit_seconds,
            "start_time": time.time(),
            "thread": agent_thread,
            "status": "running"
        }
        agent_thread.start()
        return agent_id

    def _simulate_agent_work(self, agent_id: str, agent_type: str, task_description: str, runtime_limit_seconds: int):
        """Simulates the work performed by a spawned agent."""
        logger.info(f"Agent {agent_id[:8]} ({agent_type}) started working on: '{task_description[:50]}'")
        try:
            # Simulate work time
            work_duration = min(runtime_limit_seconds, 10) # Simulate a max of 10s work
            time.sleep(work_duration)
            logger.info(f"Agent {agent_id[:8]} ({agent_type}) finished its simulated task.")
            self.active_containers[agent_id]["status"] = "completed"
        except Exception as e:
            logger.error(f"Agent {agent_id[:8]} ({agent_type}) encountered an error: {e}")
            self.active_containers[agent_id]["status"] = "failed"
        finally:
            # In a real system, you might stop the Docker container here
            # For simulation, just update status
            pass

    def get_agent_status(self, agent_id: str) -> dict | None:
        """Returns the status of a specific simulated agent."""
        agent_info = self.active_containers.get(agent_id)
        if agent_info:
            current_status = agent_info["status"]
            if current_status == "running" and not agent_info["thread"].is_alive():
                current_status = "exited" # Thread finished, but status wasn't explicitly set
            
            elapsed_time = time.time() - agent_info["start_time"]
            
            return {
                "id": agent_id,
                "type": agent_info["type"],
                "task": agent_info["task"],
                "status": current_status,
                "is_alive": agent_info["thread"].is_alive(),
                "elapsed_time": round(elapsed_time, 2),
                "runtime_limit": agent_info["runtime_limit"]
            }
        return None

    def get_all_agent_statuses(self) -> list:
        """Returns status for all active/known agents."""
        statuses = []
        for agent_id in list(self.active_containers.keys()): # Iterate over a copy to avoid modification during iteration
            status = self.get_agent_status(agent_id)
            if status:
                statuses.append(status)
            else:
                # If get_agent_status returns None, it implies the agent was potentially removed
                if agent_id in self.active_containers:
                    del self.active_containers[agent_id] # Clean up if no longer retrievable
        return statuses

    def cleanup_completed_agents(self):
        """Removes completed or failed agents that are no longer active."""
        agents_to_remove = [
            agent_id for agent_id, info in self.active_containers.items()
            if info["status"] in ["completed", "failed"] and not info["thread"].is_alive()
        ]
        for agent_id in agents_to_remove:
            logger.info(f"AgentOrchestrator: Cleaning up agent {agent_id[:8]} (Status: {self.active_containers[agent_id]['status']}).")
            del self.active_containers[agent_id]
