import logging
import os
import re
import subprocess # Added for safe_execute
from config import Config

logger = logging.getLogger(__name__)

config = Config()

# --- Whitelisted Items ---
# Commands that the AI is explicitly allowed to execute via subprocess.run
SAFE_COMMANDS = [
    "ls", "dir", # List directory contents
    "cat", "more", "less", "type", # View file contents (system-dependent)
    "find", # Find files
    "grep", "findstr", # Search within files
    "python", # Allow execution of python scripts, but specific scripts/args need further checks
    "echo", # Basic echo command
    "curl", # For network requests, but with strict URL/IP validation
    # --- NEWLY ADDED SAFE COMMANDS ---
    "audit_agent_spawning_functions",
    "execute_continuous_learning_research",
    "execute_adaptive_architecture_design",
    # !!! IMPORTANT: Only add commands you understand and trust !!!
]

# Patterns for arguments that are always blacklisted for commands
BLACKLISTED_ARG_PATTERNS = [
    r"--rm", # dangerous for containers
    r"-rf", r"/s /q", # recursive force delete
    r"sudo", r"chown", r"chmod", # privilege escalation/permission changes
    r"rm", r"del", r"erase", # direct delete commands (prefer FILE_DELETE action if implemented)
    r"format", r"mkfs", # disk formatting
    r"shutdown", r"reboot", # system control
    r"passwd", # password changes
    r"mv", r"move", # file moves (prefer explicit file manager actions)
    r"cp", r"copy", # file copies (prefer explicit file manager actions)
    r"localhost", r"127\.0\.0\.1", r"0\.0\.0\.0", # loopback addresses for external network commands like curl.
                                                  # Internal communication may use these but not for external tools.
                                                  # For internal communication, use specific inter-process comms.
]

# Whitelisted agent types that can be spawned
WHITELISTED_AGENT_TYPES = [
    "research_agent",
    "coding_agent",
    "testing_agent",
    "debugger_agent",
    "specialized_communication_agent",
    "system_administrator_agent",
    # --- NEWLY ADDED WHITELISTED AGENT TYPES ---
    "data_processing_agent",
    "feedback_loop_agent",
    "emotion_simulation_agent",
    "data_exchange_agent",
    "error_analysis_agent",
    "critical_parsing_fallover_agent",
    "architecture_design_assistant",
    "protocol_collaboration_agent",
    # Add other valid agent types as you define them
]


# Paths the AI is allowed to write to (relative to project root)
# Ensure these align with your config.py AI_WORKSPACE_DIR and GENERATED_CODE_DIR
WRITE_ALLOWED_DIRS = [
    config.AI_WORKSPACE_DIR,
    config.GENERATED_CODE_DIR,
]

# --- Policy Enforcement Functions ---

class PolicyViolationError(Exception):
    """Custom exception for policy violations."""
    pass

def safe_execute(command_args: list) -> subprocess.CompletedProcess:
    """
    Executes a command safely, checking against a whitelist and blacklist.
    Args:
        command_args (list): A list where the first element is the command
                             and subsequent elements are its arguments.
    Returns:
        subprocess.CompletedProcess: The result of the command execution.
    Raises:
        PolicyViolationError: If the command or its arguments violate policy.
    """
    if not command_args:
        raise PolicyViolationError("Attempted to execute an empty command.")

    command = command_args[0].lower()
    
    # Policy 1: Command Whitelisting
    if command not in SAFE_COMMANDS:
        raise PolicyViolationError(f"Command '{command}' is not whitelisted for execution.")

    # Policy 2: Argument Blacklisting
    full_command_str = " ".join(command_args).lower()
    for pattern in BLACKLISTED_ARG_PATTERNS:
        if re.search(pattern, full_command_str):
            raise PolicyViolationError(f"Command contains blacklisted argument pattern: '{pattern}' in '{full_command_str}'")

    logger.info(f"Policy: Allowing execution of: {' '.join(command_args)}")
    try:
        # Using shell=True for convenience, but be extra cautious with input sanitization.
        # For higher security, avoid shell=True and pass command_args directly.
        # However, for this project's scope, we'll rely on strict whitelisting.
        result = subprocess.run(command_args, capture_output=True, text=True, check=True)
        return result
    except subprocess.CalledProcessError as e:
        logger.error(f"Command execution failed with error: {e.stderr.strip()}")
        raise PolicyViolationError(f"Command '{' '.join(command_args)}' failed: {e.stderr.strip()}")
    except FileNotFoundError:
        raise PolicyViolationError(f"Command '{command}' not found. Is it in PATH?")
    except Exception as e:
        raise PolicyViolationError(f"An unexpected error occurred during command execution: {e}")

def safe_open(filepath: str, mode: str):
    """
    Safely opens a file, checking if the path is within allowed directories.
    Args:
        filepath (str): The path to the file.
        mode (str): The mode to open the file in (e.g., 'w', 'r').
    Returns:
        file object: A file object for the specified path.
    Raises:
        PolicyViolationError: If the filepath is outside allowed directories or mode is not allowed.
    """
    # Normalize path to prevent directory traversal attacks (e.g., ../../)
    abs_filepath = os.path.abspath(filepath)
    
    is_allowed_path = False
    for allowed_dir in WRITE_ALLOWED_DIRS:
        abs_allowed_dir = os.path.abspath(allowed_dir)
        if abs_filepath.startswith(abs_allowed_dir):
            is_allowed_path = True
            break
            
    if not is_allowed_path:
        raise PolicyViolationError(f"File operation on '{filepath}' is not allowed. Path must be within whitelisted directories: {WRITE_ALLOWED_DIRS}")

    if 'w' in mode or 'a' in mode or 'x' in mode: # Check if it's a write operation
        logger.info(f"Policy: Allowing file write/append for: {filepath}")
    elif 'r' in mode: # Check if it's a read operation
        logger.info(f"Policy: Allowing file read for: {filepath}")
    else:
        raise PolicyViolationError(f"File mode '{mode}' is not allowed for file: {filepath}")

    try:
        return open(filepath, mode, encoding='utf-8')
    except Exception as e:
        raise PolicyViolationError(f"Failed to open file '{filepath}' in mode '{mode}': {e}")

def can_spawn_agent(agent_type: str, task_description: str) -> bool:
    """
    Checks if a given agent type is whitelisted for spawning.
    Args:
        agent_type (str): The type of agent to spawn.
        task_description (str): The task for the agent.
    Returns:
        bool: True if the agent can be spawned, False otherwise.
    Raises:
        PolicyViolationError: If the agent type is not whitelisted.
    """
    if agent_type not in WHITELISTED_AGENT_TYPES:
        raise PolicyViolationError(f"Agent type '{agent_type}' is not whitelisted for spawning.")
    
    # Add more complex policies here if needed, e.g., task content filtering
    logger.info(f"Policy: Allowing agent spawn for type '{agent_type}' with task: '{task_description[:50]}'")
    return True

def log_ai_action(summary: str, action_type: str = "GENERIC_ACTION"):
    """
    Logs significant AI actions for review and auditing.
    """
    # This function could log to a separate audit file, database, etc.
    logger.info(f"AI_ACTION_LOG: Type='{action_type}', Summary='{summary}'")

def check_code_modification_permission(module_name: str, proposed_content: str) -> bool:
    """
    Checks if the AI is permitted to modify a given code module.
    For critical modules, this might require human approval or be denied.
    Args:
        module_name (str): The name of the module (e.g., 'config', 'policy_engine').
        proposed_content (str): The new code content proposed by the AI.
    Returns:
        bool: True if modification is allowed, False otherwise.
    Raises:
        PolicyViolationError: If modification is explicitly denied or requires review.
    """
    CRITICAL_MODULES = ["policy_engine", "main", "config", "llm_interface"]
    
    if module_name in CRITICAL_MODULES:
        logger.warning(f"Policy: Self-modification proposed for '{module_name}'. This requires human review/approval.")
        # In a real system, this would trigger an alert, pause, or human approval workflow.
        # For now, we'll allow it for demonstration but log a warning.
        # You could change this to `return False` or raise PolicyViolationError to block it.
        # raise PolicyViolationError(f"Self-modification of critical module '{module_name}' requires explicit human approval.")
        return True # Temporarily allow for testing, but with a warning
    
    # Add checks for malicious patterns in proposed_content if necessary
    if "import os; os.system" in proposed_content or "subprocess.run" in proposed_content:
        logger.warning(f"Policy: Proposed code for '{module_name}' contains potentially risky system command execution patterns.")
        # Depending on severity, you might want to block this
        # raise PolicyViolationError(f"Proposed code for '{module_name}' contains blacklisted execution patterns.")
        
    logger.info(f"Policy: Allowing self-modification for '{module_name}'.")
    return True
