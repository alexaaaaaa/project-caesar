import logging
import logging.handlers
import os

def setup_logger():
    """Sets up a comprehensive logger for the AI system."""
    logger = logging.getLogger('ai_system')
    logger.setLevel(logging.INFO) # Default level

    # Ensure the logs directory exists
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    log_file_path = os.path.join(log_dir, 'ai_agent_log.jsonl')

    # Create formatters
    # Console formatter (more human-readable)
    console_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # File formatter (JSONL for easy parsing later)
    json_formatter = logging.Formatter('{"timestamp": "%(asctime)s", "name": "%(name)s", "level": "%(levelname)s", "message": "%(message)s"}')

    # Console handler
    if not any(isinstance(handler, logging.StreamHandler) for handler in logger.handlers):
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        ch.setFormatter(console_formatter)
        logger.addHandler(ch)

    # File handler (JSONL format, daily rotation)
    if not any(isinstance(handler, logging.handlers.TimedRotatingFileHandler) and handler.baseFilename.endswith('.jsonl') for handler in logger.handlers):
        fh = logging.handlers.TimedRotatingFileHandler(
            log_file_path,
            when='midnight',
            interval=1,
            backupCount=7, # Keep 7 days of logs
            encoding='utf-8'
        )
        fh.setLevel(logging.DEBUG) # Log all debug messages to file
        fh.setFormatter(json_formatter)
        logger.addHandler(fh)

    logger.info("Logger setup complete.")
    return logger

