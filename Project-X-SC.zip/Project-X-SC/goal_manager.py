import logging
import json
import os
from datetime import datetime

logger = logging.getLogger(__name__)

# Define a constant for where goals are stored
GOALS_FILE = os.path.join(os.path.dirname(__file__), 'goals.json')

class Goal:
    def __init__(self, description: str, priority: float = 0.5, status: str = "pending", sub_tasks: list = None):
        self.description = description
        self.priority = priority
        self.status = status
        self.sub_tasks = sub_tasks if sub_tasks is not None else []
        self.created_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S IDT')
        self.updated_at = self.created_at

    def __repr__(self):
        return f"Goal(desc='{self.description[:50]}...', status='{self.status}', prio={self.priority})"

    def to_dict(self):
        return {
            "description": self.description,
            "priority": self.priority,
            "status": self.status,
            "sub_tasks": self.sub_tasks,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }

    @classmethod
    def from_dict(cls, data: dict):
        goal = cls(
            description=data['description'],
            priority=data.get('priority', 0.5),
            status=data.get('status', 'pending'),
            sub_tasks=data.get('sub_tasks')
        )
        goal.created_at = data.get('created_at', goal.created_at)
        goal.updated_at = data.get('updated_at', goal.updated_at)
        return goal


class GoalManager:
    def __init__(self, goals_file: str = GOALS_FILE, memory_manager=None):
        logger.info(f"GoalManager initialized, managing goals in {goals_file}.")
        self.goals_file = goals_file
        self.goals: list[Goal] = []
        self.memory_manager = memory_manager # Optional: for logging goal changes to main memory
        self._load_goals()

    def _load_goals(self):
        if os.path.exists(self.goals_file):
            try:
                with open(self.goals_file, 'r', encoding='utf-8') as f:
                    goals_data = json.load(f)
                    self.goals = [Goal.from_dict(d) for d in goals_data]
                logger.info(f"Loaded {len(self.goals)} goals from {self.goals_file}.")
            except (json.JSONDecodeError, FileNotFoundError) as e:
                logger.warning(f"Could not load goals from {self.goals_file}: {e}. Starting with no goals.")
            except Exception as e:
                logger.error(f"Error loading goals from {self.goals_file}: {e}", exc_info=True)
        else:
            logger.info(f"No existing goals file found at {self.goals_file}.")

    def _save_goals(self):
        try:
            with open(self.goals_file, 'w', encoding='utf-8') as f:
                json.dump([g.to_dict() for g in self.goals], f, indent=2)
            logger.debug(f"Saved {len(self.goals)} goals to {self.goals_file}.")
        except Exception as e:
            logger.error(f"Error saving goals to {self.goals_file}: {e}")

    def add_goal(self, goal: Goal, save: bool = True):
        """Adds a new goal to the manager."""
        self.goals.append(goal)
        if self.memory_manager:
            self.memory_manager.add_memory(f"New Goal Added: {goal.description}", type="goal_update")
        logger.info(f"GoalManager: Added goal: '{goal.description}' (Status: {goal.status})")
        if save:
            self._save_goals()

    def get_active_goals(self) -> list[Goal]:
        """Returns goals that are not 'completed' or 'abandoned'."""
        return [g for g in self.goals if g.status not in ["completed", "abandoned"]]

    def update_goal_status(self, description_partial: str, new_status: str, save: bool = True):
        """Updates the status of a goal based on a partial description."""
        updated = False
        for goal in self.goals:
            if description_partial.lower() in goal.description.lower():
                goal.status = new_status
                goal.updated_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S IDT')
                logger.info(f"GoalManager: Updated status for goal '{goal.description}' to '{new_status}'")
                if self.memory_manager:
                    self.memory_manager.add_memory(f"Goal Status Updated: '{goal.description}' to '{new_status}'", type="goal_update")
                updated = True
                break # Assuming partial match is for a unique goal or only update the first
        if not updated:
            logger.warning(f"GoalManager: No goal found matching '{description_partial}' for status update.")
        if save:
            self._save_goals()
        return updated

    def get_all_goals(self) -> list[Goal]:
        return self.goals

    # You might add methods to prioritize, remove goals, etc.