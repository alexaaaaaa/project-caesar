import logging
from ollama import Client # Assuming you're using ollama

logger = logging.getLogger(__name__)

class LLMInterface:
    def __init__(self, model_name: str = "llama3", base_url: str = 'http://localhost:11434'):
        self.model_name = model_name
        self.client = Client(host=base_url)
        logger.info(f"LLMInterface initialized with model: {self.model_name}, host: {base_url}")

    def get_response(self, prompt: str, system_message: str = "") -> str:
        """
        Sends a single prompt to the LLM and gets a response.
        Primarily for one-off requests or initial thought generation.
        """
        messages = []
        if system_message:
            messages.append({'role': 'system', 'content': system_message})
        messages.append({'role': 'user', 'content': prompt})

        try:
            response = self.client.chat(model=self.model_name, messages=messages)
            content = response['message']['content']
            logger.debug(f"LLM response (get_response): {content[:100]}...")
            return content
        except Exception as e:
            logger.error(f"Error calling LLM (get_response) with model {self.model_name}: {e}", exc_info=True)
            raise # Re-raise to be handled upstream

    def chat(self, messages: list[dict]) -> str:
        """
        Sends a list of messages (conversation history) to the LLM and gets a response.
        Useful for maintaining conversational context.
        Messages should be in the format: [{'role': 'user', 'content': '...'}, {'role': 'assistant', 'content': '...'}]
        """
        if not messages:
            raise ValueError("Messages list cannot be empty for chat.")
        
        try:
            response = self.client.chat(model=self.model_name, messages=messages)
            content = response['message']['content']
            logger.debug(f"LLM response (chat): {content[:100]}...")
            return content
        except Exception as e:
            logger.error(f"Error calling LLM (chat) with model {self.model_name}: {e}", exc_info=True)
            raise # Re-raise to be handled upstream