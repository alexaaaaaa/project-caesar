import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class TaskManager:
    def __init__(self):
        logger.info("TaskManager initialized.")
        self.tasks = {} # Stores tasks: {task_id: {"description": "", "status": "", "due_date": ""}}
        self.next_task_id = 1

    def add_task(self, description: str, due_date: str = None, priority: str = "medium"):
        """Adds a new task to the manager."""
        task_id = self.next_task_id
        self.next_task_id += 1
        task_entry = {
            "id": task_id,
            "description": description,
            "status": "pending",
            "created_at": datetime.now().strftime('%Y-%m-%d %H:%M:%S IDT'),
            "due_date": due_date,
            "priority": priority
        }
        self.tasks[task_id] = task_entry
        logger.info(f"TaskManager: Added task {task_id}: '{description}' (Status: pending)")
        return task_id

    def update_task_status(self, task_id: int, status: str):
        """Updates the status of an existing task."""
        if task_id in self.tasks:
            self.tasks[task_id]["status"] = status
            logger.info(f"TaskManager: Updated task {task_id} status to '{status}'")
            return True
        logger.warning(f"TaskManager: Task {task_id} not found for status update.")
        return False

    def get_task(self, task_id: int) -> dict:
        """Retrieves a specific task by ID."""
        return self.tasks.get(task_id)

    def get_all_tasks(self) -> list:
        """Returns a list of all current tasks."""
        return list(self.tasks.values())

    def get_pending_tasks(self) -> list:
        """Returns a list of tasks with 'pending' status."""
        return [task for task in self.tasks.values() if task["status"] == "pending"]

    def remove_task(self, task_id: int) -> bool:
        """Removes a task from the manager."""
        if task_id in self.tasks:
            del self.tasks[task_id]
            logger.info(f"TaskManager: Removed task {task_id}.")
            return True
        logger.warning(f"TaskManager: Task {task_id} not found for removal.")
        return False