# config.py
import os

class Config:
    OLLAMA_MODEL = "phi4-mini" # Or whatever model you are using, e.g., "llama3:70b"
    MAX_ITERATIONS = 10 # Example limit, adjust as needed
    AI_WORKSPACE_DIR = os.path.join(os.path.dirname(__file__), "ai_workspace")
    GENERATED_CODE_DIR = os.path.join(os.path.dirname(__file__), "generated_code")