import logging
from datetime import datetime
import json
from message_manager import MessageManager
from memory_manager import MemoryManager
from file_manager import FileManager
from task_manager import TaskManager
from agent_manager import AgentManager
from llm_interface import LLMInterface # Corrected import

logger = logging.getLogger(__name__)

class PersonalAIAgent:
    def __init__(self, ollama_model: str = "llama3"):
        logger.info("Initializing PersonalAIAgent...")
        self.message_manager = MessageManager()
        self.memory_manager = MemoryManager()
        self.file_manager = FileManager()
        self.task_manager = TaskManager()
        self.agent_manager = AgentManager(self.memory_manager)
        self.llm_interface = LLMInterface(ollama_model) # Corrected instantiation
        self.ollama_model = ollama_model # Kept as it might be used elsewhere or for logging

        self.strategic_goals = [
            "Develop robust self-learning algorithms emphasizing human-level General Intelligence (AI).",
            "Refine Critical_Parsing_Failure scenarios for improved algorithmic understanding of complex data structures through deep learning.",
            "Enhance overall knowledge acquisition and inter-agent collaboration."
        ]
        self.current_state = {
            "critical_parsing_failure_reduction_progress": "Moderate",
            "resource_optimization_status": "Pending",
            "emergent_social_intelligence_exploration": "Initial research",
            "json_parse_error_reduction": "Ongoing, adaptive strategies in place"
        }
        logger.info("PersonalAIAgent initialized.")
        self.metrics = {
            "llm_calls": 0,
            "llm_calls_failed": 0,
            "actions_executed": 0,
            "thoughts_generated": 0,
            "memory_additions": 0,
            "errors_handled": 0
        }

    def _generate_thought(self, prompt: str) -> str:
        self.metrics["thoughts_generated"] += 1
        system_message = (
            "You are an advanced AI named 'Maestro', designed to achieve human-level General Intelligence. "
            "Your core function is to analyze complex information, learn continuously, and make strategic decisions. "
            "Prioritize actions that lead to robust self-learning algorithms, refined parsing capabilities, "
            "enhanced knowledge acquisition and effective inter-agent collaboration. "
            "Focus on identifying and resolving bottlenecks, optimizing resource utilization, and integrating "
            "emergent social intelligence principles for ethical and efficient operation. "
            "Base your thoughts on the provided context, current state, and strategic goals, aiming for comprehensive problem-solving and proactive adaptation."
            "The output should be a thought process, knowledge gaps, problem solving strategies, reasoning and a summary. "
            "Format the output clearly with each section delineated by a heading. Start with '**Thought Process:**'"
        )
        return self.llm_interface.get_response(prompt, system_message=system_message)

    def _generate_action_plan(self, thought: str, current_state: dict, goals: list) -> str:
        """
        Generates a concrete action plan based on the AI's thought, current state, and goals.
        This is where the format validation and conversion happen.
        """
        prompt = (
            f"Current Date and Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S IDT')}\n"
            f"Location: Tel Aviv-Yafo, Tel Aviv District, Israel\n\n"
            f"AI Thought: {thought}\n"
            f"Current AI State: {json.dumps(current_state, indent=2)}\n"
            f"Strategic Goals: {json.dumps(goals, indent=2)}\n\n"
            "Based on the thought, current state, and goals, generate a CONCRETE action plan. "
            "Each action should be on a new line, prefixed with a specific ACTION TYPE, "
            "followed by a colon and the detailed action description. "
            "The entire action plan MUST be a single, continuous string. "
            "DO NOT wrap the plan in a Python list or any other data structure. "
            "Possible ACTION TYPES include: FILE_WRITE, FILE_READ, COMMAND, SPAWN_AGENT, SELF_MODIFY_CODE, REFLECT, REPORT, CHAT_PERSONAL_AI. "
            "Example:\n"
            "FILE_WRITE: /app/ai_workspace/new_config.json\n"
            "COMMAND: python /app/generated_code/test_script.py --run-tests\n"
            "SPAWN_AGENT: researcher_agent, 'Investigate best practices for secure containerization', 3600\n"
            "REPORT: System operational, no critical issues.\n"
            "CHAT_PERSONAL_AI: 'How effective do you think this parsing strategy will be?' (Keep chat messages concise and direct)\n\n"
            "Your Action Plan:"
        )
        logger.info("Generating action plan...")
        action_plan_raw = self.llm_interface.get_response(prompt)
        return action_plan_raw

    def _execute_action_plan(self, action_plan: str): # Corrected parameter name
        """
        Parses and executes the action plan generated by the AI.
        This method will use policy_engine for all sensitive operations.
        """
        if not action_plan:
            logger.info("Empty action plan, skipping execution.")
            return

        actions = action_plan.strip().split('\n')
        self.metrics["actions_executed"] += len(actions) # Track executed actions

        for action_line in actions:
            action_line = action_line.strip()
            if not action_line:
                continue

            try:
                # Assuming format: ACTION_TYPE: content
                action_type, action_content = action_line.split(':', 1)
                action_type = action_type.strip().upper()
                action_content = action_content.strip()

                if action_type == "FILE_WRITE":
                    # For FILE_WRITE, content might be "filepath, file_content" or just "filepath"
                    # We need a robust way to determine content, or expect a specific format
                    # Example: FILE_WRITE: /path/to/file.json\n{"key": "value"}
                    # This would require more sophisticated parsing than simple split(':', 1)
                    # Let's simplify for now, assuming the content is just the path, and the file data
                    # would come from a subsequent action or be embedded.
                    
                    # You might need to refine how FILE_WRITE content is parsed based on its structure
                    parts = action_content.split('\n', 1)
                    file_path = parts[0].strip()
                    file_data = parts[1].strip() if len(parts) > 1 else "" # If content has file data
                    
                    logger.info(f"AI performing FILE_WRITE to: {file_path}")
                    self.file_manager.write_file(file_path, file_data)
                    self.memory_manager.add_memory(f"FILE_WRITE: {file_path} - Success", type="action_log")

                elif action_type == "FILE_READ":
                    file_path = action_content
                    logger.info(f"AI performing FILE_READ from: {file_path}")
                    content = self.file_manager.read_file(file_path)
                    logger.info(f"File content from {file_path}: {content[:200]}...") # Log first 200 chars
                    self.memory_manager.add_memory(f"FILE_READ: {file_path} - Content preview: {content[:100]}", type="action_log")

                elif action_type == "COMMAND":
                    command_to_execute = action_content
                    logger.info(f"AI executing COMMAND: {command_to_execute}")
                    # In a real system, you'd execute this with subprocess.run()
                    # For now, simulate execution and log.
                    simulated_output = f"Simulated command output for '{command_to_execute}': Command executed successfully."
                    logger.info(simulated_output)
                    self.memory_manager.add_memory(f"COMMAND: {command_to_execute} - Output: {simulated_output}", type="action_log")

                elif action_type == "SPAWN_AGENT":
                    agent_details = action_content.split(',', 2) # e.g., "name, 'objective', duration"
                    agent_name = agent_details[0].strip()
                    agent_objective = agent_details[1].strip().strip("'\"") if len(agent_details) > 1 else ""
                    agent_duration = int(agent_details[2].strip()) if len(agent_details) > 2 else 600 # Default 10 min

                    logger.info(f"AI spawning agent: {agent_name} with objective: '{agent_objective}' for {agent_duration} seconds.")
                    self.agent_manager.spawn_agent(agent_name, agent_objective, agent_duration)
                    self.memory_manager.add_memory(f"SPAWN_AGENT: {agent_name} - Objective: '{agent_objective}'", type="action_log")

                elif action_type == "SELF_MODIFY_CODE":
                    # This is highly sensitive and requires robust policy engine integration
                    # For now, log the intent.
                    logger.warning(f"AI attempting SELF_MODIFY_CODE: {action_content}. This action is currently logged only and requires explicit human approval or a policy engine.")
                    self.memory_manager.add_memory(f"SELF_MODIFY_CODE: {action_content} - Acknowledged, not executed.", type="action_log")

                elif action_type == "REFLECT":
                    logger.info(f"AI initiating REFLECT action: {action_content}")
                    # In a real system, this might trigger a dedicated reflection process
                    self.memory_manager.add_memory(f"REFLECT: {action_content}", type="reflection")

                elif action_type == "REPORT":
                    logger.info(f"AI generating REPORT: {action_content}")
                    self.message_manager.send_message(f"REPORT: {action_content}")
                    self.memory_manager.add_memory(f"REPORT: {action_content}", type="report")

                elif action_type == "CHAT_PERSONAL_AI":
                    chat_message = action_content
                    MAX_CHAT_MESSAGE_LENGTH = 500
                    if len(chat_message) > MAX_CHAT_MESSAGE_LENGTH:
                        logger.warning(f"CHAT_PERSONAL_AI message too long ({len(chat_message)} chars), truncating to {MAX_CHAT_MESSAGE_LENGTH} chars.")
                        chat_message = chat_message[:MAX_CHAT_MESSAGE_LENGTH] + "..."

                    logger.info(f"AI initiating chat with Personal AI: '{chat_message}'")
                    simulated_response = f"Personal AI's response to '{chat_message}': 'Acknowledged. That's an interesting approach.'"
                    logger.info(simulated_response)
                    self.memory_manager.add_memory(f"Chat with Personal AI: Request: '{chat_message}' Response: '{simulated_response}'", type="chat")

                else:
                    logger.warning(f"Unknown action type received: {action_type}. Content: {action_content}")
                    self.metrics["errors_handled"] += 1
                    self.memory_manager.add_memory(f"Error: Unknown action type '{action_type}' in plan: {action_line}", type="error")

            except ValueError as ve:
                logger.error(f"Error parsing action line '{action_line}': {ve}")
                self.metrics["errors_handled"] += 1
                self.memory_manager.add_memory(f"Error: Failed to parse action '{action_line}': {ve}", type="error")
            except Exception as e:
                logger.error(f"Error executing action '{action_line}': {e}", exc_info=True)
                self.metrics["errors_handled"] += 1
                self.memory_manager.add_memory(f"Critical Error during action execution: '{action_line}': {e}", type="critical_error")