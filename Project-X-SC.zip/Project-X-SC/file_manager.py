import logging
import os

logger = logging.getLogger(__name__)

class FileManager: # <-- ENSURE THIS LINE IS EXACTLY AS SHOWN AND NOT INDENTED
    def __init__(self):
        logger.info("FileManager initialized.")
        # Define a base directory for AI operations if needed
        self.base_dir = os.path.abspath("./ai_workspace")
        os.makedirs(self.base_dir, exist_ok=True) # Ensure directory exists
        logger.info(f"AI workspace directory: {self.base_dir}")

    def _get_full_path(self, relative_path: str) -> str:
        """Ensures paths are within the designated workspace and are absolute."""
        full_path = os.path.join(self.base_dir, relative_path)
        # Simple security check: prevent path traversal (e.g., ../../)
        if not os.path.abspath(full_path).startswith(self.base_dir):
            raise ValueError("Attempted path traversal detected! Operation denied.")
        return full_path

    def read_file(self, file_path: str) -> str:
        """Reads content from a specified file."""
        full_path = self._get_full_path(file_path)
        if not os.path.exists(full_path):
            logger.warning(f"FileManager: File not found: {full_path}")
            return f"Error: File not found at {file_path}"
        try:
            with open(full_path, 'r', encoding='utf-8') as f:
                content = f.read()
            logger.info(f"FileManager: Read file: {file_path}")
            return content
        except Exception as e:
            logger.error(f"FileManager: Error reading file {file_path}: {e}")
            return f"Error reading file: {e}"

    def write_file(self, file_path: str, content: str):
        """Writes content to a specified file."""
        full_path = self._get_full_path(file_path)
        # Ensure directory exists for the file
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        try:
            with open(full_path, 'w', encoding='utf-8') as f:
                f.write(content)
            logger.info(f"FileManager: Wrote to file: {file_path}")
            return "Success"
        except Exception as e:
            logger.error(f"FileManager: Error writing to file {file_path}: {e}")
            return f"Error writing file: {e}"

    def list_directory(self, path: str = "") -> list:
        """Lists contents of a directory."""
        full_path = self._get_full_path(path)
        if not os.path.isdir(full_path):
            logger.warning(f"FileManager: Directory not found or not a directory: {full_path}")
            return [f"Error: Directory not found or not a directory at {path}"]
        try:
            contents = os.listdir(full_path)
            logger.info(f"FileManager: Listed directory: {path}")
            return contents
        except Exception as e:
            logger.error(f"FileManager: Error listing directory {path}: {e}")
            return [f"Error listing directory: {e}"]