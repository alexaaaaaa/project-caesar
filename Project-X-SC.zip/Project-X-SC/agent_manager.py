import logging
import uuid
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)

class BaseAgent(ABC):
    """Abstract base class for all AI agents."""
    def __init__(self, agent_id: str, task_description: str, memory_manager):
        self.agent_id = agent_id
        self.task_description = task_description
        self.memory_manager = memory_manager
        self.status = "idle" # or "active", "completed", "failed"
        logger.info(f"BaseAgent {self.agent_id} initialized for task: {self.task_description[:50]}...")

    @abstractmethod
    def execute(self):
        """Abstract method to be implemented by concrete agents."""
        pass

class AgentManager:
    def __init__(self, memory_manager):
        logger.info("AgentManager initialized.")
        self.active_agents = {} # Dictionary to store active agents by ID
        self.memory_manager = memory_manager

    def spawn_agent(self, agent_type: str, task_description: str, runtime_limit_seconds: int = None):
        """
        Spawns a new agent of the specified type with a given task.
        Args:
            agent_type (str): The type of agent to spawn (e.g., "research_agent").
            task_description (str): The task assigned to the agent.
            runtime_limit_seconds (int): Optional runtime limit in seconds.
        Returns:
            str: The ID of the spawned agent.
        """
        agent_id = str(uuid.uuid4())
        agent = None

        # NOTE: This is where you would instantiate different agent classes
        # based on agent_type. For now, we'll use a placeholder or
        # a generic agent if specific ones aren't defined.
        if agent_type == "research_agent":
            # agent = ResearchAgent(agent_id, task_description, self.memory_manager)
            logger.warning(f"ResearchAgent not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager) # Placeholder
        elif agent_type == "coding_agent":
            logger.warning(f"CodingAgent not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager) # Placeholder
        elif agent_type == "testing_agent":
            logger.warning(f"TestingAgent not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager) # Placeholder
        elif agent_type == "debugger_agent":
            logger.warning(f"DebuggerAgent not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager) # Placeholder
        elif agent_type == "specialized_communication_agent":
            logger.warning(f"SpecializedCommunicationAgent not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager) # Placeholder
        elif agent_type == "system_administrator_agent":
            logger.warning(f"SystemAdministratorAgent not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager) # Placeholder
        # --- NEW AGENT TYPES (add specific classes here when implemented) ---
        elif agent_type == "data_processing_agent":
            logger.warning(f"data_processing_agent not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager)
        elif agent_type == "feedback_loop_agent":
            logger.warning(f"feedback_loop_agent not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager)
        elif agent_type == "emotion_simulation_agent":
            logger.warning(f"emotion_simulation_agent not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager)
        elif agent_type == "data_exchange_agent":
            logger.warning(f"data_exchange_agent not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager)
        elif agent_type == "error_analysis_agent":
            logger.warning(f"error_analysis_agent not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager)
        elif agent_type == "critical_parsing_fallover_agent":
            logger.warning(f"critical_parsing_fallover_agent not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager)
        elif agent_type == "architecture_design_assistant":
            logger.warning(f"architecture_design_assistant not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager)
        elif agent_type == "protocol_collaboration_agent":
            logger.warning(f"protocol_collaboration_agent not yet implemented, spawning generic agent for {agent_type}")
            agent = BaseAgent(agent_id, task_description, self.memory_manager)
        else:
            logger.error(f"Unknown agent type requested: {agent_type}")
            raise ValueError(f"Unknown agent type: {agent_type}")

        self.active_agents[agent_id] = agent
        logger.info(f"Agent {agent_id} ({agent_type}) created for task: '{task_description[:50]}...'")
        return agent_id

    def get_all_agent_statuses(self) -> dict:
        """Returns a dictionary of all active agents and their statuses."""
        statuses = {agent_id: agent.status for agent_id, agent in self.active_agents.items()}
        return statuses

    def terminate_agent(self, agent_id: str):
        """Terminates an active agent."""
        if agent_id in self.active_agents:
            del self.active_agents[agent_id]
            logger.info(f"Agent {agent_id} terminated.")
            return True
        logger.warning(f"Attempted to terminate non-existent agent: {agent_id}")
        return False

    def get_active_agents(self) -> list:
        """Returns a list of all active agent objects."""
        return list(self.active_agents.values())
