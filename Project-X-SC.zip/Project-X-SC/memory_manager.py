import logging
import json
import os
from datetime import datetime
from typing import Optional

logger = logging.getLogger(__name__)

MEMORY_FILE = "memories.json" # File to store memories

class MemoryManager:
    def __init__(self):
        self.memories = [] # Stores list of memory entries
        self._load_memories()
        logger.info("MemoryManager initialized.")

    def _load_memories(self):
        """Loads memories from a JSON file."""
        if os.path.exists(MEMORY_FILE):
            try:
                with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
                    self.memories = json.load(f)
                logger.info(f"Loaded {len(self.memories)} memories from {MEMORY_FILE}.")
            except (json.JSONDecodeError, FileNotFoundError) as e:
                logger.warning(f"Could not load memories from {MEMORY_FILE}: {e}. Starting with empty memories.")
            except Exception as e:
                logger.error(f"Error loading memories from {MEMORY_FILE}: {e}")

    def _save_memories(self):
        """Saves current memories to a JSON file."""
        try:
            with open(MEMORY_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.memories, f, indent=2)
            logger.debug(f"Saved {len(self.memories)} memories to {MEMORY_FILE}.")
        except Exception as e:
            logger.error(f"Error saving memories to {MEMORY_FILE}: {e}")

    def add_memory(self, content: str, type: str = "general", source: str = "AISystem"):
        """
        Adds a new memory entry.
        Args:
            content (str): The content of the memory.
            type (str): The type of memory (e.g., "thought", "observation", "action_result", "feedback").
            source (str): The source of the memory (e.g., "AISystem", "ResearcherAgent", "User").
        """
        memory_entry = {
            "timestamp": datetime.now().isoformat(),
            "type": type,
            "source": source,
            "content": content
        }
        self.memories.append(memory_entry)
        self._save_memories() # Save after each addition for persistence
        logger.debug(f"Added memory (type={type}): {content[:80]}...")

    def get_recent_memories(self, count: int = 5, memory_type: Optional[str] = None, as_string: bool = False) -> list[dict] | str: # Changed 'type' to 'memory_type'
        """
        Retrieves the most recent memories, optionally filtered by type.
        Args:
            count (int): The maximum number of recent memories to retrieve.
            memory_type (Optional[str]): If provided, filter memories by this type.
            as_string (bool): If True, returns memories as a single formatted string.
        Returns:
            list[dict] | str: A list of memory dictionaries or a formatted string.
        """
        filtered_mems = self.memories
        if memory_type: # Use memory_type here
            filtered_mems = [m for m in self.memories if m.get("type") == memory_type]
        
        recent_mems = filtered_mems[-count:]

        if as_string:
            return "\n".join([f"[{m['timestamp']}] ({m['type']}) {m['content'][:150]}..." for m in recent_mems])
        return recent_mems

    def search_memories(self, keyword: str, count: int = 5) -> list[dict]:
        """
        Searches memories for a specific keyword.
        Args:
            keyword (str): The keyword to search for.
            count (int): The maximum number of matching memories to retrieve.
        Returns:
            list[dict]: A list of matching memory dictionaries.
        """
        found_mems = [m for m in self.memories if keyword.lower() in m["content"].lower()]
        return found_mems[-count:]
