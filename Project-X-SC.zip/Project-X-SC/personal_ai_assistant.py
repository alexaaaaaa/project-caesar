import logging
import json
from llm_interface import LLMInterface # Ensure LLMInterface is imported

logger = logging.getLogger(__name__)

class PersonalAIAssistant:
    def __init__(self, ollama_model: str = "phi4-mini"):
        logger.info("Initializing PersonalAIAssistant...")
        self.ollama_model = ollama_model
        self.llm_interface = LLMInterface(ollama_model)
        logger.info("PersonalAIAssistant initialized.")

    def provide_feedback(self, context: dict) -> str:
        """
        Generates feedback from the Personal AI Assistant's perspective
        based on the provided context from the main AISystem.
        """
        prompt = (
            f"As a Personal AI Assistant, review the following summary of the AISystem's recent activities and state:\n"
            f"{json.dumps(context, indent=2)}\n\n"
            "Provide concise, actionable feedback focusing on:\n"
            "- Key areas of concern (e.g., recurring errors, policy violations, unwhitelisted agents).\n"
            "- Progress towards strategic goals.\n"
            "- Suggestions for immediate improvements or next steps for the AISystem.\n"
            "Keep it direct and insightful. Start with 'Based on my analysis, I see...'"
        )
        system_message = (
            "You are a helpful and analytical Personal AI Assistant. "
            "Your role is to provide constructive feedback to the main AISystem. "
            "Be empathetic but direct, focusing on actionable insights."
        )
        try:
            response = self.llm_interface.get_response(prompt, system_message=system_message)
            logger.info("PersonalAIAssistant: Generating response for chat iteration.")
            return response
        except Exception as e:
            logger.error(f"Error generating personal assistant feedback: {e}")
            return f"Error generating feedback: {e}"
