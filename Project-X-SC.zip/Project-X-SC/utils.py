import os
import logging
import datetime
from typing import Optional

from logging_setup import setup_logger

logger = setup_logger()

def save_code_snippet(filename: str, code_content: str, description: str = "No description provided", subdir: str = "generated_code") -> Optional[str]:
    """
    Saves a generated code snippet to a file within a specified subdirectory.

    Args:
        filename (str): The name of the file to save (e.g., 'my_function.py').
        code_content (str): The actual code content as a string.
        description (str): A brief description of the code snippet.
        subdir (str): The subdirectory within the project to save the code.

    Returns:
        Optional[str]: The full path to the saved file if successful, None otherwise.
    """
    code_dir = os.path.join(os.getcwd(), subdir)
    os.makedirs(code_dir, exist_ok=True) # Ensure the directory exists

    full_path = os.path.join(code_dir, filename)

    try:
        with open(full_path, 'w') as f:
            f.write(code_content)
        
        logger.info(f"💾 Code snippet saved: '{filename}' in '{subdir}/'. Description: '{description}'")
        logger.info(f"    Full path: {full_path}")
        return full_path
    except IOError as e:
        logger.error(f"Failed to save code snippet '{filename}' to '{full_path}': {e}")
        return None
    except Exception as e:
        logger.error(f"An unexpected error occurred while saving code: {e}")
        return None

if __name__ == "__main__":
    # Example Usage:
    test_code = """
def hello_world_generated():
    print("Hello from AI-generated code!")

if __name__ == "__main__":
    hello_world_generated()
"""
    save_code_snippet("test_output.py", test_code, "A test function for demonstrating code generation.")

    # You would then manually inspect 'generated_code/test_output.py'
    # And run it like: python generated_code/test_output.py