import logging
import json
import os
from datetime import datetime

logger = logging.getLogger(__name__)

MESSAGES_FILE = "messages.json" # File to store messages

class MessageManager:
    def __init__(self):
        self.messages = []
        self._load_messages()
        logger.info("MessageManager initialized.")

    def _load_messages(self):
        """Loads messages from a JSON file."""
        if os.path.exists(MESSAGES_FILE):
            try:
                with open(MESSAGES_FILE, 'r', encoding='utf-8') as f:
                    self.messages = json.load(f)
                logger.info(f"Loaded {len(self.messages)} messages from {MESSAGES_FILE}.")
            except (json.JSONDecodeError, FileNotFoundError) as e:
                logger.warning(f"Could not load messages from {MESSAGES_FILE}: {e}. Starting with empty messages.")
            except Exception as e:
                logger.error(f"Error loading messages from {MESSAGES_FILE}: {e}")

    def _save_messages(self):
        """Saves current messages to a JSON file."""
        try:
            with open(MESSAGES_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.messages, f, indent=2)
            logger.debug(f"Saved {len(self.messages)} messages to {MESSAGES_FILE}.")
        except Exception as e:
            logger.error(f"Error saving messages to {MESSAGES_FILE}: {e}")

    def send_message(self, sender: str, recipient: str, content: str, msg_type: str = "general"): # Renamed to send_message
        """
        Adds a new message to the system.
        Args:
            sender (str): The entity sending the message (e.g., "AISystem", "User", "ResearcherAgent").
            recipient (str): The intended recipient (e.g., "User/Orchestrator", "AISystem", "DebuggerAgent").
            content (str): The actual message content.
            msg_type (str): The type of message (e.g., "general", "feedback", "report", "error").
        """
        message = {
            "timestamp": datetime.now().isoformat(),
            "sender": sender,
            "recipient": recipient,
            "type": msg_type,
            "content": content
        }
        self.messages.append(message)
        self._save_messages() # Save after each message to ensure persistence
        logger.info(f"Message from {sender} to {recipient} ({msg_type}): {content[:80]}...")

    def get_messages_for_recipient(self, recipient: str, count: int = 5) -> list[dict]:
        """
        Retrieves recent messages for a specific recipient.
        Args:
            recipient (str): The recipient to filter messages for.
            count (int): The maximum number of recent messages to retrieve.
        Returns:
            list[dict]: A list of message dictionaries.
        """
        filtered_messages = [m for m in self.messages if m.get("recipient") == recipient]
        return filtered_messages[-count:]

    def get_all_messages(self, count: int = 10) -> list[dict]:
        """
        Retrieves the most recent messages from the entire system.
        Args:
            count (int): The maximum number of recent messages to retrieve.
        Returns:
            list[dict]: A list of message dictionaries.
        """
        return self.messages[-count:]
