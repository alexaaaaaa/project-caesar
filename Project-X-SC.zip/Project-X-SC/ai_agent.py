import logging
import json
import os
from datetime import datetime
import re

from llm_interface import LLMInterface
from memory_manager import MemoryManager
from file_manager import FileManager
from task_manager import TaskManager
from agent_manager import AgentManager
from message_manager import MessageManager
from goal_manager import GoalManager, Goal # Ensure Goal is imported if used directly

logger = logging.getLogger(__name__)

# Define constants for file paths
AI_STATE_FILE = "ai_state.json"

class AISystem: # This is the main orchestrator
    def __init__(self, ollama_model: str = "phi4-mini"):
        logger.info("Initializing AISystem (Main Orchestrator)...")
        self.ollama_model = ollama_model
        self.llm_interface = LLMInterface(ollama_model)

        self.memory_manager = MemoryManager()
        self.file_manager = FileManager()
        self.task_manager = TaskManager()
        self.agent_manager = AgentManager(self.memory_manager)
        self.message_manager = MessageManager()
        self.goal_manager = GoalManager(memory_manager=self.memory_manager)

        self.iteration = 0
        self.current_focus = "System initialization and strategic goal alignment."
        self.last_self_evaluation = {}
        self.last_parsed_action_plan = ""
        self.last_inter_agent_feedback = ""
        self.failures = [] # To store recent failures for reporting

        # Define default metrics
        self.default_metrics = {
            "llm_calls_successful": 0,
            "llm_calls_failed": 0,
            "json_parse_successful": 0,
            "json_parse_failed": 0,
            "goal_updates_applied": 0,
            "memory_stores": 0,
            "actions_executed": 0,
            "thoughts_generated": 0
        }
        # Initialize metrics with default values, which might be overwritten by loaded state
        self.metrics = self.default_metrics.copy()

        self._load_ai_state() # Load previous state if available
        logger.info("AISystem initialized.")

    def _load_ai_state(self):
        """Loads the AI's state from a file."""
        if os.path.exists(AI_STATE_FILE):
            try:
                with open(AI_STATE_FILE, 'r', encoding='utf-8') as f:
                    state = json.load(f)
                    self.iteration = state.get("iteration", 0)
                    self.current_focus = state.get("current_focus", "System initialization and strategic goal alignment.")
                    
                    # Merge loaded metrics with default metrics
                    loaded_metrics = state.get("metrics", {})
                    self.metrics = {**self.default_metrics, **loaded_metrics}

                    self.last_self_evaluation = state.get("last_self_evaluation", {})
                    self.failures = state.get("failures", [])
                logger.info(f"Loaded AI state from {AI_STATE_FILE}. Current iteration: {self.iteration}")
            except (json.JSONDecodeError, FileNotFoundError) as e:
                logger.warning(f"Could not load AI state from {AI_STATE_FILE}: {e}. Starting with default state.")
                self.metrics = self.default_metrics.copy()
            except Exception as e:
                logger.error(f"Error loading AI state from {AI_STATE_FILE}: {e}", exc_info=True)
                self.metrics = self.default_metrics.copy()
        else:
            logger.info(f"No existing AI state file found at {AI_STATE_FILE}. Starting with default state.")
            self.metrics = self.default_metrics.copy()

    def _save_ai_state(self):
        """Saves the AI's current state to a file."""
        state = {
            "iteration": self.iteration,
            "current_focus": self.current_focus,
            "metrics": self.metrics,
            "last_self_evaluation": self.last_self_evaluation,
            "failures": self.failures,
        }
        try:
            with open(AI_STATE_FILE, 'w', encoding='utf-8') as f:
                json.dump(state, f, indent=2)
            logger.info(f"AI state saved to {AI_STATE_FILE}.")
        except Exception as e:
            logger.error(f"Error saving AI state to {AI_STATE_FILE}: {e}")

    def run_iteration(self):
        """Executes a single iteration of the AI's thought-action cycle."""
        self.iteration += 1
        logger.info(f"--- Running AISystem Iteration {self.iteration} ---")
        self.metrics["actions_executed"] += 1

        # 1. Gather Context / Observations
        current_context = self._gather_context()

        # 2. Generate Thought
        logger.info("AISystem: Generating thought...")
        ai_thought = self._generate_thought(current_context)
        self.metrics["thoughts_generated"] += 1
        self.memory_manager.add_memory(f"AISystem Thought: {ai_thought}", type="thought")
        logger.info(f"AISystem Thought:\n{ai_thought}")

        # 3. Generate Action Plan
        logger.info("AISystem: Generating action plan...")
        action_plan = self._generate_action_plan(ai_thought, current_context)
        self.memory_manager.add_memory(f"AISystem Action Plan: {action_plan}", type="action_plan_generated")
        self.last_parsed_action_plan = action_plan # Store for main.py to execute
        logger.info(f"AISystem Action Plan:\n{action_plan}")

        # 4. Self-Evaluation (simplified for now)
        self.last_self_evaluation = {
            "performance_assessment": "Good (simulated)",
            "identified_problems": "None (simulated)",
            "proposed_improvements": "Optimize LLM prompt for next cycle (simulated)"
        }
        self.memory_manager.add_memory(f"AISystem Self-Evaluation: {self.last_self_evaluation}", type="self_evaluation")


    def _gather_context(self) -> dict:
        """Gathers all relevant context for the LLM to make decisions."""
        context = {
            "current_time": datetime.now().strftime('%Y-%m-%d %H:%M:%S IDT'),
            "location": "Tel Aviv-Yafo, Tel Aviv District, Israel",
            "current_iteration": self.iteration,
            "main_focus": self.current_focus,
            "strategic_goals": [goal.to_dict() for goal in self.goal_manager.get_active_goals()],
            "recent_memories": self.memory_manager.get_recent_memories(count=5, memory_type="general"), # Get general memories
            "recent_failures": self.failures[-3:],
            "active_tasks": self.task_manager.get_pending_tasks(),
            "active_agents": self.agent_manager.get_all_agent_statuses(),
            "last_inter_agent_feedback": self.last_inter_agent_feedback,
            "metrics_snapshot": self.metrics
        }
        return context

    def _generate_thought(self, context: dict) -> str:
        """Generates the AI's internal thought process."""
        prompt = (
            f"Current Context:\n{json.dumps(context, indent=2)}\n\n"
            "As the main AI orchestrator 'AISystem', analyze the context above. "
            "Formulate a detailed thought process. Consider:\n"
            "- What are the most pressing issues or opportunities based on recent failures/feedback?\n"
            "- How well are strategic goals being met? What immediate next steps are needed?\n"
            "- How can resources be best utilized (tasks, agents, file ops, commands)?\n"
            "- What knowledge gaps exist that require further exploration or agent spawning?\n"
            "- Propose a refined current focus if necessary.\n"
            "Your response should be a comprehensive internal monologue, detailing reasoning, problem-solving, and strategic considerations. "
            "Start with '**Thought Process:**'"
        )
        system_message = (
            "You are the central AI orchestrator, responsible for high-level strategic planning and resource allocation. "
            "Maintain a global perspective. Prioritize long-term goals and system stability. "
            "Your output is an internal thought process, not direct commands."
        )
        response = self.llm_interface.get_response(prompt, system_message=system_message)
        focus_match = re.search(r"Refined Current Focus:\s*(.+)", response, re.IGNORECASE)
        if focus_match:
            self.current_focus = focus_match.group(1).strip()
            logger.info(f"AISystem current focus updated to: {self.current_focus}")
        return response

    def _generate_action_plan(self, thought: str, context: dict) -> str:
        """Generates a concrete action plan based on the thought and context."""
        prompt = (
            f"AI Thought: {thought}\n\n"
            f"Current Context:\n{json.dumps(context, indent=2)}\n\n"
            "Based on the thought and context, generate a CONCRETE, executable action plan. "
            "Each action must be on a new line, prefixed with a specific ACTION TYPE, "
            "followed by a colon and the detailed action description. "
            "The entire action plan MUST be a single, continuous string. "
            "DO NOT wrap the plan in a Python list or any other data structure. "
            "STRICTLY adhere to the following ACTION TYPE formats. No extra prefixes like 'ACTION_TYPE:'.\n"
            "Valid ACTION TYPES and their EXACT required formats:\n"
            "- COMMAND: <command_line_string> (e.g., COMMAND: ls -l /path/to/dir, COMMAND: curl -I http://localhost:11434/api/chat)\n"
            "- FILE_WRITE: <filepath>; content='<file_content_string>' (filepath MUST be in 'ai_workspace/' or 'generated_code/', content MUST be explicitly 'content=' and quoted with SINGLE quotes)\n"
            "- FILE_READ: <filepath> (filepath MUST be in 'ai_workspace/' or 'generated_code/')\n"
            "- SPAWN_AGENT: type=<agent_type>; task='<task_description>'[; runtime=<seconds>] (agent_type must be whitelisted. For 'type' and 'runtime' values, DO NOT use quotes. 'task' must be in single quotes)\n"
            "- SELF_MODIFY_CODE: <module_name>; content='<new_code_string>' (module_name like 'logging_setup.py' or 'generated_code/my_module.py'. IMPORTANT: 'content' MUST be a single-line string enclosed in SINGLE quotes. Use '\\n' for newlines and '\\t' for tabs within the string. DO NOT use triple quotes.)\n"
            "- REFLECT: <reflection_statement>\n"
            "- REPORT: <summary_message>\n"
            "- GOAL_UPDATE: goal_description='<full_or_partial_description_of_goal_EXACTLY_AS_IS_IN_GOALS_LIST>'; status='<new_status>' "
            "  (IMPORTANT: Both 'goal_description' and 'status' values MUST be enclosed in SINGLE quotes. "
            "  The 'goal_description' must EXACTLY match an existing goal or be a highly unique partial match from the provided strategic goals list. DO NOT invent new goals with GOAL_UPDATE. If a goal doesn't exist, it cannot be updated. Ensure there is a semicolon ';' between 'goal_description' and 'status'.)\n"
            "- MEMORY_ADD: type='<memory_type>'; content='<content_string>' "
            "  (IMPORTANT: Both 'type' and 'content' values MUST be enclosed in SINGLE quotes. "
            "  DO NOT use placeholders like '<new_memory_type>' or '<content describing new memory storage mechanism>'; provide concrete, specific values!)\n"
            "Ensure all string values in parameters are properly quoted with SINGLE quotes if they contain spaces or special characters, as specified above. "
            "Prioritize file operations within 'ai_workspace/' or 'generated_code/'.\n"
            "If no action is needed, output 'REFLECT: No immediate action required.'\n\n"
            "Your Action Plan:"
        )
        system_message = (
            "You are an action planning module. Convert high-level thoughts into precise, executable commands. "
            "Adhere STRICTLY to the specified action formats. Be direct and avoid conversational filler. "
            "Do NOT add any extra prefixes or conversational text before the action plan."
        )
        response = self.llm_interface.get_response(prompt, system_message=system_message)
        return response







