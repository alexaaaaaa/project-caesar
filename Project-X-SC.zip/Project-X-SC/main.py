import logging
import os
import json
from datetime import datetime
import re
import shlex # Added import for shlex

from ai_agent import AISystem
from personal_ai_assistant import PersonalAIAssistant
from policy_engine import PolicyViolationError, safe_execute, safe_open, can_spawn_agent, log_ai_action, check_code_modification_permission
from config import Config
from file_manager import FileManager # Import FileManager to ensure directories exist
from goal_manager import GoalManager # Import GoalManager for initial goal setup

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load configuration
config = Config()

def ensure_directories_exist():
    """Ensures AI workspace and generated code directories exist."""
    os.makedirs(config.AI_WORKSPACE_DIR, exist_ok=True)
    os.makedirs(config.GENERATED_CODE_DIR, exist_ok=True)
    logger.info("Ensured AI workspace and generated code directories exist.")

def initialize_ai_system():
    """Initializes the AISystem and PersonalAIAssistant."""
    ai_system = AISystem(ollama_model=config.OLLAMA_MODEL)
    personal_ai_assistant = PersonalAIAssistant(ollama_model=config.OLLAMA_MODEL)
    return ai_system, personal_ai_assistant

def setup_strategic_goals(goal_manager):
    """Sets up initial strategic goals if they don't exist."""
    initial_goals = [
        "Develop robust self-learning algorithms to achieve human-level General AI.",
        "Explore principles of emergent social intelligence and ethical AI interaction.",
        "Optimize resource utilization and computational efficiency for continuous AI operation.",
        "Implement a feedback loop for continuous improvement of AI capabilities.",
        "Implement a feedback Loop for Simulation of feelings and emotions in AI agents.",
        "Revised: Develop advanced communication protocols for inter-agent collaboration.",
        "Enhance the quality review mechanism by integrating a more robust filtering system.",
        "consider implementing helper functions to streamline the process of filtering and categorizing error logs.",
        "Refine self-learning algorithms to improve handling of Critical_Parsing_Failure scenarios.",
        "Enhance adaptive knowledge acquisition architecture to support robust self-learning algorithms."
    ]

    if not goal_manager.get_all_goals():
        logger.info("Setting up initial strategic goals...")
        for goal_description in initial_goals:
            goal_manager.add_goal(goal_description)
        logger.info("Initial strategic goals set.")
    else:
        logger.info("Strategic goals already exist. Current goals:")
        for goal in goal_manager.get_all_goals():
            logger.info(f"- {goal.description} ({goal.status})")

def execute_safe_action_plan(ai_system: AISystem, action_plan: str):
    """
    Parses and safely executes the AI's action plan.
    Args:
        ai_system (AISystem): The main AI system instance.
        action_plan (str): The raw string action plan from the AI.
    """
    actions = [line.strip() for line in action_plan.split('\n') if line.strip()]

    # References for easier access
    memory_manager = ai_system.memory_manager
    file_manager = ai_system.file_manager
    task_manager = ai_system.task_manager
    agent_orchestrator = ai_system.agent_manager
    goal_manager = ai_system.goal_manager
    message_manager = ai_system.message_manager
    llm_interface = ai_system.llm_interface # Added for LLM status check

    # Helper function to check if a file exists within allowed directories
    def check_file_exists_in_workspace(filepath: str) -> bool:
        abs_filepath = os.path.abspath(filepath)
        # --- FIX: Correctly reference the allowed directories from config ---
        allowed_dirs = [os.path.abspath(config.AI_WORKSPACE_DIR), os.path.abspath(config.GENERATED_CODE_DIR)]
        
        is_allowed_path = False
        for allowed_dir in allowed_dirs:
            if abs_filepath.startswith(allowed_dir):
                is_allowed_path = True
                break
        
        if not is_allowed_path:
            logger.warning(f"File path '{filepath}' is not within allowed workspace or generated code directories.")
            return False # Not in allowed dir
        
        return os.path.exists(filepath) # Now check if it actually exists

    for action_line in actions:
        action_type_match = re.match(r"([A-Z_]+):(.+)", action_line)
        if not action_type_match:
            logger.warning(f"Malformed action line, skipping: {action_line}")
            ai_system.failures.append(f"Malformed action: {action_line}")
            continue

        action_type = action_type_match.group(1).strip()
        action_content = action_type_match.group(2).strip()

        logger.info(f"Executing action type: {action_type}, content: {action_content[:100]}...")

        try:
            if action_type == "COMMAND":
                # --- START: Handle symbolic commands and specific system commands internally ---
                if action_content == "execute_adaptive_architecture_design":
                    logger.info("Executing internal command: execute_adaptive_architecture_design (Placeholder)")
                    # Placeholder for actual logic for this "command"
                    # This would involve calling a specific Python function or method
                    memory_manager.add_memory("Internal command 'execute_adaptive_architecture_design' simulated success.", type="internal_command_result")
                    continue # Skip to next action, don't pass to safe_execute
                elif action_content == "execute_continuous_learning_research":
                    logger.info("Executing internal command: execute_continuous_learning_research (Placeholder)")
                    # Placeholder for actual logic for this "command"
                    memory_manager.add_memory("Internal command 'execute_continuous_learning_research' simulated success.", type="internal_command_result")
                    continue
                elif action_content == "audit_agent_spawning_functions":
                    logger.info("Executing internal command: audit_agent_spawning_functions (Placeholder)")
                    # Placeholder for actual logic
                    memory_manager.add_memory("Internal command 'audit_agent_spawning_functions' simulated success.", type="internal_command_result")
                    continue
                elif action_content.startswith("curl -I http://localhost:11434/api/chat"):
                    logger.info("Executing internal command: checking LLM host status.")
                    try:
                        # Attempt a simple chat completion to check LLM connectivity
                        test_response = llm_interface.get_response("ping", system_message="Respond with pong.")
                        if "pong" in test_response.lower():
                            logger.info(f"LLM host (localhost:11434) is responsive. Response: {test_response[:50]}...")
                            memory_manager.add_memory("LLM host check successful.", type="llm_status")
                            ai_system.metrics["llm_calls_successful"] += 1
                        else:
                            raise Exception("Unexpected response from LLM host.")
                    except Exception as llm_e:
                        logger.error(f"LLM host check failed: {llm_e}")
                        memory_manager.add_memory(f"LLM host check failed: {llm_e}", type="llm_status_failure")
                        ai_system.metrics["llm_calls_failed"] += 1
                    continue # Skip to next action

                elif action_content.startswith("ls -l"):
                    target_path_raw = action_content.replace("ls -l", "").strip()
                    # Determine if it's ai_workspace or generated_code based on the prompt's likely intent
                    if "ai_workspace" in target_path_raw:
                        dir_to_list = config.AI_WORKSPACE_DIR
                    elif "generated_code" in target_path_raw:
                        dir_to_list = config.GENERATED_CODE_DIR
                    else:
                        logger.warning(f"Unsupported 'ls -l' target path, not within AI workspace: {target_path_raw}")
                        ai_system.failures.append(f"Unsupported ls path: {target_path_raw}")
                        continue

                    logger.info(f"Executing internal command: listing directory contents for {dir_to_list}")
                    try:
                        if os.path.exists(dir_to_list) and os.path.isdir(dir_to_list):
                            items = os.listdir(dir_to_list)
                            listed_content = "\n".join(items)
                            logger.info(f"Directory listing for {dir_to_list}:\n{listed_content}")
                            memory_manager.add_memory(f"Directory listing for {dir_to_list}: {listed_content}", type="file_system_list")
                        else:
                            logger.warning(f"Directory {dir_to_list} does not exist for listing.")
                            memory_manager.add_memory(f"Directory {dir_to_list} does not exist for listing.", type="file_system_error")
                    except Exception as list_e:
                        logger.error(f"Failed to list directory {dir_to_list}: {list_e}")
                        memory_manager.add_memory(f"Failed to list directory {dir_to_list}: {list_e}", type="file_system_error")
                    continue # Skip to next action

                elif action_content.startswith("python "):
                    # Example: python ai_workspace/utils/error_filtering.py --help
                    command_parts = shlex.split(action_content)
                    script_path_relative = command_parts[1] # Assumes 'python script.py' format
                    
                    if check_file_exists_in_workspace(script_path_relative):
                        logger.info(f"Executing internal command: running python script {script_path_relative}")
                        # Reconstruct command for safe_execute, ensuring python itself is allowed
                        # and that the arguments don't contain blacklisted patterns.
                        try:
                            result = safe_execute(command_parts) # This will check 'python' and its args
                            logger.info(f"Python script '{script_path_relative}' executed. Output: {result.stdout.strip()}")
                            memory_manager.add_memory(f"Python script executed: {script_path_relative}. Output: {result.stdout.strip()}", type="script_output")
                        except PolicyViolationError as e:
                            logger.error(f"Policy violation during script execution: {e}")
                            ai_system.failures.append(f"Script Policy Violation: {script_path_relative} - {e}")
                        except Exception as e:
                            logger.error(f"Error executing python script '{script_path_relative}': {e}", exc_info=True)
                            ai_system.failures.append(f"Python_Script_Execution_Error: {script_path_relative} - {e}")
                    else:
                        logger.warning(f"Python script '{script_path_relative}' not found in allowed directories or does not exist.")
                        ai_system.failures.append(f"Missing Python script: {script_path_relative}")
                    continue # Skip to next action
                # --- END: Handle symbolic commands internally ---

                # If not an internally handled symbolic command, try external safe_execute
                command_args = shlex.split(action_content)
                logger.info(f"Attempting safe_execute for external command: {command_args}")
                result = safe_execute(command_args) # This will now be for truly external commands
                logger.info(f"Command '{' '.join(command_args)}' executed. Output: {result.stdout.strip()}")
                memory_manager.add_memory(f"Command executed: {' '.join(command_args)}. Output: {result.stdout.strip()}", type="command_output")


            elif action_type == "FILE_WRITE":
                # Updated regex to be more robust for content matching, assuming single quotes.
                # The prompt now strictly enforces single quotes for content.
                match = re.match(r"(.+?); content='((?:[^'\\]|\\.)*)'", action_content) 
                if match:
                    filepath = match.group(1).strip()
                    content = match.group(2).encode('utf-8').decode('unicode_escape')
                    logger.info(f"Attempting safe_open (write) for: {filepath}")
                    with safe_open(filepath, 'w') as f:
                        f.write(content)
                    logger.info(f"Successfully wrote to: {filepath}")
                    memory_manager.add_memory(f"Wrote to file: {filepath}", type="file_operation")
                else:
                    logger.warning(f"Malformed FILE_WRITE command (check single quotes for content): {action_content}")
                    ai_system.failures.append(f"Malformed FILE_WRITE: {action_content}")

            elif action_type == "FILE_READ":
                filepath = action_content.strip()
                if check_file_exists_in_workspace(filepath): # Check existence before opening
                    logger.info(f"Attempting safe_open (read) for: {filepath}")
                    with safe_open(filepath, 'r') as f:
                        content = f.read()
                    logger.info(f"Successfully read from: {filepath}. Content length: {len(content)}.")
                    memory_manager.add_memory(f"Read from file: {filepath}. Content: {content[:200]}...", type="file_operation")
                else:
                    logger.warning(f"FILE_READ failed: File '{filepath}' does not exist or is not in allowed directories.")
                    ai_system.failures.append(f"FILE_READ_Error: File not found or not accessible: {filepath}")

            elif action_type == "SPAWN_AGENT":
                # --- FIX: Adjusted regex for SPAWN_AGENT to be more flexible with key=value pairs ---
                # It now expects task='...' to be quoted, but type and runtime can be unquoted or quoted.
                match = re.match(r"type=(['\"]?[\w_]+['\"]?); task='((?:[^'\\]|\\.)*)'(?:; runtime=(\d+))?", action_content)
                if match:
                    # Clean the type value in case it was quoted
                    agent_type = match.group(1).strip("'\"") 
                    task_description = match.group(2)
                    runtime_limit = int(match.group(3)) if match.group(3) else None

                    logger.info(f"Attempting to spawn agent '{agent_type}' for task: {task_description[:50]}...")
                    if can_spawn_agent(agent_type, task_description):
                        agent_id = agent_orchestrator.spawn_agent(agent_type, task_description, runtime_limit_seconds=runtime_limit)
                        logger.info(f"Agent '{agent_type}' spawned with ID: {agent_id}")
                        memory_manager.add_memory(f"Spawned agent {agent_id} ({agent_type}) for task: {task_description}", type="agent_management")
                else:
                    logger.warning(f"Malformed SPAWN_AGENT command (check type/task/runtime format): {action_content}")
                    ai_system.failures.append(f"Malformed SPAWN_AGENT: {action_content}")

            elif action_type == "GOAL_UPDATE":
                # --- FIX: Adjusted regex for GOAL_UPDATE to handle missing semicolon and both quote types ---
                # It now supports 'key=value' or 'key="value"' and flexible separation.
                match = re.match(r"goal_description=(['\"])(.*?)\1(?:[;\s,]*?)status=(['\"])(.*?)\3", action_content)
                if match:
                    goal_desc_partial = match.group(2).encode('utf-8').decode('unicode_escape')
                    new_status = match.group(4).encode('utf-8').decode('unicode_escape')
                    
                    # Fuzzy match for goal description
                    matched_goal = None
                    # Prioritize exact match, then case-insensitive partial match
                    for goal in goal_manager.get_all_goals():
                        if goal.description == goal_desc_partial: # Exact match first
                            matched_goal = goal
                            break
                    if not matched_goal: # If no exact match, try case-insensitive partial
                        for goal in goal_manager.get_all_goals():
                            if goal_desc_partial.lower() in goal.description.lower():
                                matched_goal = goal
                                break
                    
                    if matched_goal:
                        updated = goal_manager.update_goal_status(matched_goal.description, new_status)
                        if updated:
                            logger.info(f"Updated goal '{matched_goal.description}' to status '{new_status}'.")
                            memory_manager.add_memory(f"Goal updated: '{matched_goal.description}' to '{new_status}'", type="goal_management")
                            ai_system.metrics["goal_updates_applied"] += 1
                        else:
                            logger.warning(f"Goal '{matched_goal.description}' status not changed (already {new_status} or invalid status).")
                            ai_system.failures.append(f"Goal status not changed: {matched_goal.description} to {new_status}")
                    else:
                        logger.warning(f"GoalManager: No goal found matching '{goal_desc_partial}' for status update.")
                        ai_system.failures.append(f"Goal not found/updated: {goal_desc_partial}")
                else:
                    logger.warning(f"Malformed GOAL_UPDATE command: Expected goal_description='...' (or \") status='...' (or \"). Full command: {action_content}")
                    ai_system.failures.append(f"Malformed GOAL_UPDATE: {action_content}")

            elif action_type == "MEMORY_ADD":
                # Robust regex for MEMORY_ADD to handle both single and double quotes,
                # but the prompt should still enforce single quotes.
                match = re.match(r"type='((?:[^'\\]|\\.)*)'; content=['\"]((?:[^'\\]|\\.)*)['\"]", action_content)
                if match:
                    mem_type = match.group(1).encode('utf-8').decode('unicode_escape')
                    mem_content = match.group(2).encode('utf-8').decode('unicode_escape')
                    memory_manager.add_memory(mem_content, type=mem_type)
                    logger.info(f"Added memory of type '{mem_type}': {mem_content[:50]}...")
                    ai_system.metrics["memory_stores"] += 1
                else:
                    logger.warning(f"Malformed MEMORY_ADD command (check quotes): {action_content}")
                    ai_system.failures.append(f"Malformed MEMORY_ADD: {action_content}")

            elif action_type == "SELF_MODIFY_CODE":
                # --- FIX: Adjusted regex for SELF_MODIFY_CODE to strictly expect single quotes and handle escaped newlines ---
                match = re.match(r"(.+?); content='((?:[^'\\]|\\.)*)'", action_content)
                if match:
                    module_name = match.group(1).strip()
                    # Decode unicode escapes like \n, \t, etc.
                    new_code_content = match.group(2).encode('utf-8').decode('unicode_escape') 
                    
                    # Construct a safe path for code modification within GENERATED_CODE_DIR
                    # Ensure filename is valid and ends with .py
                    if not module_name.endswith(".py"):
                        module_name += ".py"
                    
                    filepath = os.path.join(config.GENERATED_CODE_DIR, module_name)
                    
                    # Ensure the target directory exists for this module
                    os.makedirs(os.path.dirname(filepath), exist_ok=True)

                    if check_code_modification_permission(os.path.basename(filepath).replace(".py", ""), new_code_content):
                        with open(filepath, 'w', encoding='utf-8') as f:
                            f.write(new_code_content)
                        logger.info(f"AI proposed self-modification for '{module_name}'. Saved to '{filepath}'. Awaiting human review/automated deployment.")
                        log_ai_action(f"AI proposed self-modification for '{module_name}'.", "SELF_MODIFICATION_PROPOSED")
                        memory_manager.add_memory(f"Proposed self-modification for {module_name}", type="self_modification")
                    else:
                        logger.warning(f"Self-modification for '{module_name}' denied by policy.")
                        ai_system.failures.append(f"Self-modification denied: {module_name}")
                else:
                    logger.warning(f"Malformed SELF_MODIFY_CODE command: Expected 'filepath; content='<single_quoted_string_with_escaped_newlines>'. Full: {action_content}")
                    ai_system.failures.append(f"Malformed SELF_MODIFY_CODE: {action_content}")

            elif action_type == "REFLECT":
                reflection_message = action_content.strip()
                logger.info(f"AI Reflection: {reflection_message}")
                memory_manager.add_memory(f"Reflection: {reflection_message}", type="reflection")

            elif action_type == "REPORT":
                report_message = action_content.strip()
                logger.info(f"AI Report: {report_message}")
                ai_system.message_manager.send_message(sender="AISystem", recipient="User/Orchestrator", content=report_message, msg_type="report")
                memory_manager.add_memory(f"Report: {report_message}", type="report")

            else:
                logger.warning(f"Unrecognized action type: {action_type}. Content: {action_content}")
                ai_system.failures.append(f"Unrecognized action: {action_type}")

        except PolicyViolationError as e:
            logger.error(f"Policy violation during action execution: {e}")
            ai_system.failures.append(f"Policy Violation: {action_type} - {e}")
        except Exception as e:
            logger.error(f"Error executing action '{action_line}': {e}", exc_info=True)
            ai_system.failures.append(f"Action_Execution_Error: {action_type} - {e}")


def main():
    ensure_directories_exist()
    ai_system, personal_ai_assistant = initialize_ai_system()
    
    # Initialize GoalManager and setup goals
    goal_manager = ai_system.goal_manager
    setup_strategic_goals(goal_manager)

    try:
        while True:
            logger.info("\n================================================================================")
            logger.info(f"Starting Main Orchestrator Iteration: {ai_system.iteration + 1}")
            logger.info("================================================================================")

            ai_system.run_iteration()

            # Execute the action plan generated by AISystem
            if ai_system.last_parsed_action_plan:
                logger.info("Executing AISystem's action plan...")
                execute_safe_action_plan(ai_system, ai_system.last_parsed_action_plan)
                ai_system.last_parsed_action_plan = "" # Clear after execution

            # Simulate inter-agent feedback (AISystem to PersonalAIAssistant)
            logger.info("Conducting inter-agent feedback session...")
            recent_memories_str = ai_system.memory_manager.get_recent_memories(count=3, as_string=True)
            
            active_agents = ai_system.agent_manager.get_active_agents() 

            inter_agent_context = {
                "ai_system_summary": f"Iteration {ai_system.iteration}. Current focus: {ai_system.current_focus}. Last thought: {ai_system.memory_manager.get_recent_memories(memory_type='thought', count=1, as_string=True)}",
                "recent_system_activities": recent_memories_str,
                "recent_failures_count": len(ai_system.failures),
                "active_goals": [goal.description for goal in goal_manager.get_active_goals()],
                "active_agents_summary": ", ".join([f"{agent.agent_id} ({agent.task_description[:20]}...)" for agent in active_agents]),
                "metrics": ai_system.metrics 
            }
            ai_system.last_inter_agent_feedback = personal_ai_assistant.provide_feedback(inter_agent_context)
            logger.info(f"Personal AI Assistant Feedback: {ai_system.last_inter_agent_feedback}")

            # Save state at the end of each iteration
            ai_system._save_ai_state()

            # Optional: Add a delay to slow down iterations for readability/resource management
            # import time
            # time.sleep(5) 

    except KeyboardInterrupt:
        logger.info("Main orchestrator stopped by user.")
    except Exception as e:
        logger.critical(f"Unhandled critical error in main loop: {e}", exc_info=True)
        ai_system._save_ai_state() # Attempt to save state even on critical error

if __name__ == "__main__":
    main()